const a = [
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/start-00275329.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/components/pages/_layout.svelte-839cf136.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/assets/_layout-254866ae.css",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/components/pages/_error.svelte-abf5907f.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/components/pages/_page.svelte-e3aa08ec.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/components/pages/_slug_/_page.svelte-4151f889.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/assets/_page-bb5a6b75.css",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/modules/pages/_layout.js-7b9cbfbc.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/modules/pages/_page.js-ed7d2f11.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/modules/pages/_slug_/_page.js-c81992d0.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/singletons-68d82a72.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/index-4b2d5ab0.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/_layout-8d2a742b.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/_page-f17362ac.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/_page-ab6be616.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/0-b9d34d69.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/1-5a198ffd.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/2-0bd12f3a.js",
  "/_themes/_components/BB-Custom-Form/publish/assets/_app/immutable/chunks/3-1194302a.js"
], p = [], n = "1663500908204", t = self, m = `static-cache-${n}`, c = a.concat(p);
t.addEventListener("install", (s) => {
  console.log("[ServiceWorker] Install"), s.waitUntil(
    caches.open(m).then((e) => (console.log("[ServiceWorker] Pre-caching offline page"), e.addAll(c).then(() => {
      t.skipWaiting();
    })))
  );
});
t.addEventListener("activate", (s) => {
  console.log("[ServiceWorker] Activate"), s.waitUntil(
    caches.keys().then(
      async (e) => Promise.all(
        e.map((o) => {
          if (o !== m)
            return console.log("[ServiceWorker] Removing old cache", o), caches.delete(o);
        })
      )
    )
  ), t.clients.claim();
});
self.addEventListener("fetch", (s) => {
  console.log("[ServiceWorker] Fetch", s.request.url), s.request.mode === "navigate" && s.respondWith(
    fetch(s.request).catch(() => caches.open(m).then((e) => e.match("offline.html")))
  );
});
