import{default as t}from"../components/pages/_error.svelte-59152c8f.js";export{t as component};
