import{_ as r}from"./_page-ab6be616.js";import{default as t}from"../components/pages/_slug_/_page.svelte-4151f889.js";export{t as component,r as shared};
