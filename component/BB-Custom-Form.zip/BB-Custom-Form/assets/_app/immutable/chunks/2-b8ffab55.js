import{_ as r}from"./_page-f17362ac.js";import{default as t}from"../components/pages/_page.svelte-eb33eef8.js";export{t as component,r as shared};
