import{default as t}from"../components/pages/_error.svelte-7c3bcd9f.js";export{t as component};
