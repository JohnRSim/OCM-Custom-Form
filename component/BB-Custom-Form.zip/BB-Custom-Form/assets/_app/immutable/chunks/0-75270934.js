import{_ as r}from"./_layout-8d2a742b.js";import{default as t}from"../components/pages/_layout.svelte-0b606623.js";export{t as component,r as shared};
