import{_ as r}from"./_page-f17362ac.js";import{default as t}from"../components/pages/_page.svelte-e3aa08ec.js";export{t as component,r as shared};
