import{default as t}from"../components/pages/_error.svelte-62de450f.js";export{t as component};
