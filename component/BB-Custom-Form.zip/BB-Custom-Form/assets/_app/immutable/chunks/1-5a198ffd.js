import{default as t}from"../components/pages/_error.svelte-abf5907f.js";export{t as component};
